package com.example.alarmmanagement;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class DestinationActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_destination);
    }
}